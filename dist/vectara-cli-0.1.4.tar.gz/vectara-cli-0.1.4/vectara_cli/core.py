# ./vectara-cli/core.py

import requests
import json
import os
import logging

class ConfigManager:
    @staticmethod
    def set_api_keys(customer_id, api_key):
        """Sets the customer ID and API key as environment variables."""
        os.environ['VECTARA_CUSTOMER_ID'] = customer_id
        os.environ['VECTARA_API_KEY'] = api_key

    @staticmethod
    def get_api_keys():
        """Retrieves the customer ID and API key from environment variables."""
        customer_id = os.getenv('VECTARA_CUSTOMER_ID')
        api_key = os.getenv('VECTARA_API_KEY')
        if not customer_id or not api_key:
            raise ValueError("API keys are not set. Please set them using the 'set-api-keys' command.")
        return customer_id, api_key

class VectaraClient:
    def __init__(self, customer_id, api_key):
        self.base_url = "https://api.vectara.io"
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "customer-id": customer_id,
            "x-api-key": api_key
        }

    def index_text(self, corpus_id, document_id, text, context="", metadata_json="", custom_dims=None):
        if custom_dims is None:
            custom_dims = []

        url = f"{self.base_url}/v1/core/index"
        payload = {
            "customerId": self.headers["customer-id"],
            "corpusId": corpus_id,
            "document": {
                "documentId": document_id,
                "metadataJson": metadata_json,
                "parts": [
                    {
                        "text": text,
                        "context": context,
                        "metadataJson": metadata_json,
                        "customDims": custom_dims
                    }
                ],
                "defaultPartContext": context,
                "customDims": custom_dims
            }
        }

        response = requests.post(url, headers=self.headers, data=json.dumps(payload))

        if response.status_code == 200:
            response_data = response.json()
            if 'status' in response_data and response_data['status']['code'] == "OK":
                print("Indexing successful.")
                return response_data
            else:
                print("Indexing completed with status:", response_data['status']['code'])
                return response_data
        else:
            try:
                error_response = response.json()
                print(f"Error indexing text: {error_response.get('message', 'Unknown error')}")
            except json.JSONDecodeError:
                print(f"Non-JSON error response from server: {response.text}")
            return None

    def query(self, query_text, num_results=10, corpus_id=None):
        url = f"{self.base_url}/v1/query"
        data_dict = {
            "query": [
                {
                    "query": query_text,
                    "num_results": num_results,
                    "corpus_key": [
                        {
                            "customer_id": self.headers["customer-id"],
                            "corpus_id": corpus_id
                        }
                    ]
                }
            ]
        }

        response = requests.post(url, headers=self.headers, data=json.dumps(data_dict))
        if response.status_code != 200:
            print(f"Query failed with status code: {response.status_code}")
            return None

        try:
            response_data = response.json()
        except json.JSONDecodeError:
            print("Failed to parse JSON response from query.")
            return None

        return self._parse_query_response(response_data)

    def _parse_query_response(self, response_data):
        if "responseSet" in response_data:
            for response_set in response_data["responseSet"]:
                if "response" in response_set:
                    # Extracting and returning the first response for simplicity. Adjust as needed.
                    responses = response_set["response"]
                    return [self._extract_response_info(response) for response in responses]
        else:
            print("No response set found in the data")
        return []

    @staticmethod
    def _extract_response_info(response):
        return {
            "text": response.get("text", ""),
            "score": response.get("score", 0),
            "metadata": response.get("metadata", []),
            "documentIndex": response.get("documentIndex"),
            "corpusKey": response.get("corpusKey", {}),
        }
    
    def _get_index_request_json(self, corpus_id, document_id, title, metadata, section_text):
        """Constructs the JSON payload for a document to be indexed."""
        document = {
            "document_id": document_id,
            "title": title,
            "metadata_json": json.dumps(metadata),
            "section": [
                {"text": section_text},
            ],
        }

        request = {
            "customer_id": self.customer_id,
            "corpus_id": corpus_id,
            "document": document,
        }

        return json.dumps(request)

    def create_corpus(self, corpus_id, name, description, dtProvision, enabled, swapQenc, swapIenc, textless, encrypted, encoderId, metadataMaxBytes, customDimensions, filterAttributes):
        url = f"{self.base_url}/v1/create-corpus"
        payload = {
            "corpus": {
                "id": corpus_id,
                "name": name,
                "description": description,
                "dtProvision": dtProvision,
                "enabled": enabled,
                "swapQenc": swapQenc,
                "swapIenc": swapIenc,
                "textless": textless,
                "encrypted": encrypted,
                "encoderId": encoderId,
                "metadataMaxBytes": metadataMaxBytes,
                "customDimensions": customDimensions,
                "filterAttributes": filterAttributes
            }
        }

        response = requests.post(url, headers=self.headers, data=json.dumps(payload))
        
        if response.status_code == 200:
            # Assuming a successful response will have a JSON body
            try:
                response_data = response.json()
                # Check if the response contains the expected 'status' field with 'OK'
                if response_data.get('status', {}).get('code') == "OK":
                    return {"success": True, "data": response_data}
                else:
                    return {"success": False, "error": response_data.get('status', {})}
            except ValueError:
                # In case the response body does not contain valid JSON
                return {"success": False, "error": "Invalid JSON in response"}
        else:
            # Handle HTTP errors
            try:
                error_data = response.json()
                return {"success": False, "error": error_data}
            except ValueError:
                return {"success": False, "error": f"HTTP Error {response.status_code}: {response.text}"}

    def _get_index_request_json(self, corpus_id, document_id, title, metadata, section_text):
        # Assuming this method correctly formats the request payload for indexing a document.
        # This is a placeholder implementation.
        return json.dumps({
            "corpusId": corpus_id,
            "documentId": document_id,
            "title": title,
            "metadata": metadata,
            "sectionText": section_text
        })

    def index_document(self, corpus_id, document_id, title, metadata, section_text):
        """Indexes a document to the specified corpus using the Vectara platform.

        Args:
            corpus_id: ID of the corpus to which data needs to be indexed.
            document_id: Unique identifier for the document.
            title: Title of the document.
            metadata: A dictionary containing metadata about the document.
            section_text: The main content/text of the document.

        Returns:
            A tuple containing the response and a boolean indicating success or failure.
        """
        idx_address = f"{self.base_url}/v1/index"
        payload = self._get_index_request_json(corpus_id, document_id, title, metadata, section_text)
        try:
            response = requests.post(idx_address, data=payload, headers=self.headers)
            response.raise_for_status()  # Raises HTTPError for bad responses

            message = response.json()
            if "status" in message and message["status"]["code"] in ("OK", "ALREADY_EXISTS"):
                logging.info("Document indexed successfully or already exists.")
                return message, True
            else:
                logging.error("Indexing failed with status: %s", message.get("status", {}))
                return message.get("status", {}), False
        except requests.exceptions.HTTPError as e:
            logging.error("HTTP error occurred: %s", e)
            return {"code": "HTTP_ERROR", "message": str(e)}, False
        except requests.exceptions.RequestException as e:
            logging.error("Error during requests to Vectara API: %s", e)
            return {"code": "REQUEST_EXCEPTION", "message": str(e)}, False
        except ValueError as e:
            logging.error("Invalid response received from Vectara API: %s", e)
            return {"code": "INVALID_RESPONSE", "message": "The response from Vectara API could not be decoded."}, False

    def index_documents_from_folder(self, corpus_id, folder_path, return_extracted_document=False):
        """Indexes all documents in a specified folder.

        Args:
            corpus_id: The ID of the corpus to which the documents will be indexed.
            folder_path: The path to the folder containing the documents.

        Returns:
            A list of tuples, each containing the document ID and a boolean indicating success or failure.
        """
        results = []
        for file_name in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file_name)
            document_id = os.path.splitext(file_name)[0]

            try:
                response, status = self.upload_document(corpus_id, file_path, document_id=document_id, return_extracted_document=return_extracted_document)
                extracted_text = response.get('extractedText', '') if return_extracted_document else None
                results.append((document_id, status == "Success", extracted_text))
                if status != "Success":
                    logging.error(f"Failed to index document {document_id}: {response}")
                else:
                    logging.info(f"Successfully indexed document {document_id}")
            except Exception as e:
                logging.error(f"Error uploading or indexing file {file_name}: {e}")
                results.append((document_id, False, None))

        return results
 
    def delete_corpus(self, corpus_id):
        """Deletes a specified corpus.

        Args:
            corpus_id: The ID of the corpus to be deleted.

        Returns:
            A tuple containing the response JSON and a boolean indicating success or failure.
        """
        url = f"{self.base_url}/v1/delete-corpus"
        payload = json.dumps({
            "corpusId": corpus_id
        })

        try:
            response = requests.post(url, headers=self.headers, data=payload)
            response_json = response.json()

            # Check if the response has a 'status' field and handle accordingly
            if 'status' in response_json:
                vectara_status_code = response_json['status'].get('code', 'UNKNOWN')
                if vectara_status_code == 'OK':
                    logging.info("Corpus deleted successfully.")
                    return response_json, True
                else:
                    logging.error("Failed to delete corpus with Vectara status code %s, detail: %s",
                                  vectara_status_code, response_json['status'].get('statusDetail', 'No detail'))
                    return response_json, False
            else:
                logging.error("Unexpected response format: %s", response.text)
                return response_json, False
        except requests.exceptions.RequestException as e:
            logging.error("Request failed: %s", e)
            return {"error": str(e)}, False

    def upload_document(self, corpus_id, file_path, document_id=None, metadata=None, return_extracted_document=False):
        """
        Uploads and indexes a document into a corpus.

        Args:
            corpus_id: The ID of the corpus into which the document should be indexed.
            file_path: The path to the file to be uploaded.
            document_id: Optional. The Document ID to assign to the file.
            metadata: Optional. A dictionary containing user-defined metadata to attach to the document.
            return_extracted_document: Optional. If set to true, the server returns the extracted document.

        Returns:
            A tuple containing the server's response as a JSON object and a status message.
        """
        url = f"{self.base_url}/v1/upload?c={self.customer_id}&o={corpus_id}"
        if return_extracted_document:
            url += "&d=true"


        files = {'file': open(file_path, 'rb')}
        if metadata is not None:
            files['doc_metadata'] = (None, json.dumps(metadata), 'application/json')

        response = requests.post(url, headers={key: val for key, val in self.headers.items() if key != 'Content-Type'}, files=files)

        if response.status_code == 200:
            return response.json(), "Success"
        else:
            try:
                error_response = response.json()
                error_message = error_response.get('message', 'Unknown error')
            except json.JSONDecodeError:
                error_message = "Failed to parse error response."

            raise Exception(f"Failed to upload document: HTTP {response.status_code} - {error_message}")

# # Example usage
# CUSTOMER_ID = "your_customer_id"
# API_KEY = "your_api_key"
# CORPUS_ID = "your_corpus_id"
# FILE_PATH = "/path/to/your/document.pdf"
# DOCUMENT_ID = "unique_document_id"  # Optional
# METADATA = {"author": "Author Name", "title": "Document Title"}  # Optional

# vectara_client = VectaraClient(CUSTOMER_ID, API_KEY)
# try:
#     response = vectara_client.upload_document(CORPUS_ID, FILE_PATH, DOCUMENT_ID, METADATA)
#     print("Upload successful:", response)
# except Exception as e:
#     print("Upload failed:", str(e))

# # Example usage:
# CUSTOMER_ID = "your_customer_id"
# API_KEY = "your_api_key"
# CORPUS_ID = 1  # Example corpus ID, replace with actual corpus ID to delete

# vectara_client = VectaraClient(CUSTOMER_ID, API_KEY)
# response, success = vectara_client.delete_corpus(CORPUS_ID)

# if success:
#     print("Corpus deleted successfully.")
# else:
#     print("Failed to delete corpus:", response)
# # Example usage:
# CUSTOMER_ID = "your_customer_id"
# API_KEY = "your_api_key"
# CORPUS_ID = "your_corpus_id"

# vectara_client = VectaraClient(CUSTOMER_ID, API_KEY)

# # Indexing a document
# metadata = {
#     "book-name": "Another example title",
#     "collection": "Mathematics",
#     "author": "Example Author",
# }
# section_text = "The answer to the ultimate question of life, the universe, and everything is 42."
# document_id = "doc-id-2"
# title = "Another Example Title"

# response, success = vectara_client.index_document(CORPUS_ID, document_id, title, metadata, section_text)
# if success:
#     print("Document indexed successfully.")
# else:
#     print("Document indexing failed.", response)

# # Example usage:
# CUSTOMER_ID = "your_customer_id"
# API_KEY = "your_api_key"

# vectara_client = VectaraClient(CUSTOMER_ID, API_KEY)

# # Creating a corpus
# create_corpus_response = vectara_client.create_corpus(
#     corpus_id=123456789,
#     name="Example Corpus",
#     description="This is an example corpus.",
#     dtProvision=1234567890,
#     enabled=True,
#     swapQenc=False,
#     swapIenc=False,
#     textless=False,
#     encrypted=False,
#     encoderId="default",
#     metadataMaxBytes=10000,
#     customDimensions=[
#         {"name": "dimension1", "description": "First custom dimension", "servingDefault": 1.0, "indexingDefault": 1.0}
#     ],
#     filterAttributes=[
#         {"name": "filter1", "description": "First filter attribute", "indexed": True, "type": "FILTER_ATTRIBUTE_TYPE__UNDEFINED", "level": "FILTER_ATTRIBUTE_LEVEL__UNDEFINED"}
#     ]
# )
# print(create_corpus_response)
# # Example usage:
# CUSTOMER_ID = "your_customer_id"
# API_KEY = "your_api_key"
# CORPUS_ID = "your_corpus_id"

# vectara_client = VectaraClient(CUSTOMER_ID, API_KEY)

# # Indexing a document
# index_response = vectara_client.index_document(
#     corpus_id=CORPUS_ID,
#     document_id="unique_document_id",
#     text="This is the document text.",
#     context="Document context",
#     metadata_json='{"author": "John Doe"}'
# )
# print(index_response)

# # Querying
# query_response = vectara_client.query(
#     query_text="What is the meaning of life?",
#     num_results=10,
#     corpus_id=CORPUS_ID
# )
# print(query_response)
